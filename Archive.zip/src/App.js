import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
import { Switch, BrowserRouter, Route, Link } from 'react-router-dom';

class App extends Component {
  render() {
    return (
        <div>
          
          <Route exact path="/home" component={Home}></Route>
          <Route exact path="/login" component={Login}></Route>
        
        </div>
    );
  }
}

function Home ({match}) {
  console.log(match);
    return (
      <div>
        <Nav />
        {/* <BrowserRouter> */}
    
         
          <Route path={`${match.path}/content2`} component={Content2}></Route>
          <Route path={`${match.path}/content1`} component={Content1}></Route>
          <Route exact path={`${match.path}`} render={() => <div>home</div>} />
          {/* <Route component={F0F} /> */}
 
        {/* </BrowserRouter> */}
      </div>
    )
}

function Nav() {
  return (<div>
    <Link to="/home/content1" >Content1</Link>
    <Link to="/home/content2">Content2</Link>
    Navigation Bar
    <hr></hr>
  </div>);
}

function Content1() {
  return (<div>Content1</div>);
}
function Content2() {
  return (<div>Content2</div>);
}

function F0F() {
  return <div>Not Found</div>
}

function Login() {
  return (<div>Log In Page</div>)
}

export default App;
