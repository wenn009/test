import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
import { HashRouter, BrowserRouter, Route, Link } from 'react-router-dom';

class App extends Component {
  render() {
    return (
      <BrowserRouter>
      <div>
        <Route exact path="/" component={Home}></Route>
        <Route exact path="/login" component={Login}></Route>
      </div>
      </BrowserRouter>
    );
  }
}

class Home extends Component {
  render() {
    return (
      <div>
        <Nav />
        <HashRouter>
        <div>
        <Route exact path="/" component={Content1}></Route>
        <Route exact path="/content2" component={Content2}></Route>
        </div>
        </HashRouter>
      </div>
    )
  } 
}

function Nav () {
  return (<div>
    <Link to="/" >Content1</Link>
    <Link to="/content2">Content2</Link>
    Navigation Bar
    <hr></hr>
    </div>);
}

function Content1() {
  return (<div>Content1</div>);
}
function Content2() {
  return (<div>Content2</div>);
}

function Login () {
  return (<div>Log In Page</div>)
}

export default App;
